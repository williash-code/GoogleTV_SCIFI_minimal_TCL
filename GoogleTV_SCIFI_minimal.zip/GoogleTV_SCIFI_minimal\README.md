# GoogleTV_SCIFI_minimal

Home-screen setup for a TCL Smart TV Pro (G08, Google TV, Android 14), for the CleanYourTV launcher
(https://github.com/Gathin23/cleanyourtv).

## What is in it
- `theme/` - `config.json`, 12 sci-fi wallpapers (rotate every 2 minutes, shuffled), `CREDITS.md`.
  Look: glass dock band, 7 dock tiles (Sling, Netflix, Prime Video, Peacock, Paramount+, Xbox on HDMI 1, PS5 on HDMI 2),
  Settings tile last in the row, 24-hour clock, no greeting, no network pill, remote buttons mapped.
- `launcher/tvhome-custom.apk` - the launcher build this theme needs. It carries local changes that upstream does not have:
  `tile_opacity`, `tile_card`, `tile_glass`, `apps_last` theme keys, white-logo and Xbox/PS5 banners, the shorter date
  ("SUN 8 NOV"). `launcher-changes.patch` is the same change as a diff against the upstream clone.
- `debloat-disabled-packages.txt` - the packages disabled on this TV (`pm disable-user --user 0`, nothing uninstalled).

## Install (TV needs USB debugging on, same Wi-Fi)
From a CleanYourTV checkout with its venv set up (`python -m venv tools/venv`, then `pip install -r tools/requirements.txt`):
```
cp <this-folder>/launcher/tvhome-custom.apk launcher/app/build/outputs/apk/release/app-release.apk
cd launcher && TV_HOST=<tv ip> HOME_KEY_SERVICE=1 INPUT_KEY_SERVICE=1 SKIP_BUILD=1 bash build-and-install.sh && cd ..
TV_HOST=<tv ip> bash tools/theme.sh <this-folder>/theme
```
Undo the theme with `tools/theme.sh --reset`.

## Things specific to this TV
- HDMI tiles use inputs `com.tcl.tvinput/.TvPassThroughService/HW15` (HDMI 1) and `.../HW16` (HDMI 2), and borrow the tiles of
  `com.tcl.tv` and `com.tcl.suspension`. Other TVs need their own input ids (`dumpsys tv_input`) and app slots.
- Remote key codes (4062 Netflix, 4099 Prime, 190/4065 YouTube, 83 Settings) are for this remote.

## Credits
Wallpapers are from Alpha Coders (alphacoders.com/sci-fi-wallpapers); each stays the work of its owner. Logos are from Simple
Icons (CC0); the marks belong to their owners. Not affiliated with TCL, Google or any streaming service.
