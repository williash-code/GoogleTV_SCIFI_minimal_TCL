# Wallpapers
Sci-fi wallpapers from Alpha Coders (https://alphacoders.com/sci-fi-wallpapers), resized to 1920x1080.
Each image stays the work of its original artist and owner; used here for personal, non-commercial use.
Alpha Coders image IDs are in the file names.
